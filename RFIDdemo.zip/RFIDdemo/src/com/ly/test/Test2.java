package com.ly.test;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

import org.junit.Test;

import com.ly.service.impl.SignServiceImpl;

public class Test2 {
	
	private static Properties timeconfig = new Properties();
	InputStream in = null;
	
	static {
		try {
			timeconfig.load(Test2.class.getClassLoader().getResourceAsStream("time.properties"));
		} catch (IOException e) {
			throw new RuntimeException();
		}
	}
@Test
	public void sfas(){
		String id = "1 2 b";
		System.out.println(id);
		System.out.println(id.trim());
		System.out.println(id.replace(" ", ""));
	}

@Test
public void sfaaas() throws IOException{
	String path = Test2.class.getClassLoader().getResource("time.properties").toString();
	String path2 = path.substring(6,path.length());
	System.out.println(path2);
	
	in = new BufferedInputStream (new FileInputStream(path2));
	timeconfig.load(in);
	
	 FileOutputStream file = new FileOutputStream(path2);
	 timeconfig.put("signinMin", "07:05:00");

	 timeconfig.store(file, "ϵͳ�����޸�");
}
}
