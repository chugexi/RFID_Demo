package com.ly.dao;

public interface Employee_AttenceDao {

	void add(String employee_id, String attence_day_id);

	void delete(String employee_id);

}